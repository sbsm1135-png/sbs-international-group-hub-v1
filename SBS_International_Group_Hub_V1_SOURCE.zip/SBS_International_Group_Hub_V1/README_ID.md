# SBS International Group Hub V1

Aplikasi Android berbasis WebView untuk katalog offline 500 URL Facebook Group.

## Fitur
- 500 entri grup di file lokal
- Pencarian nama/tokoh/tema
- Filter berdasarkan tema
- Urutkan nama A–Z
- Favorit tersimpan di perangkat
- Buka tautan Facebook menggunakan aplikasi/browser yang tersedia
- Salin URL ke clipboard
- Tidak membutuhkan server untuk menampilkan database

## Build APK via GitHub Actions
1. Buat repository GitHub baru atau gunakan repository yang kamu pilih.
2. Upload semua isi folder project ini (folder `app`, `.github`, `build.gradle`, `settings.gradle`, `gradle.properties`) ke root repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build SBS International Group Hub APK**.
5. Tekan **Run workflow**.
6. Setelah status hijau, buka run tersebut → **Artifacts** → unduh `SBS-International-Group-Hub-debug-APK.zip`.
7. Ekstrak ZIP; file di dalamnya adalah `app-debug.apk`. Pindahkan APK ke Android untuk instalasi.

## Build lokal
Gunakan Android Studio dengan JDK 17, Android SDK Platform 35, dan Gradle 8.9. Jalankan `gradle assembleDebug`.

## Catatan
- Data berisi 500 URL yang disediakan dalam database SBS final. Tautan belum berarti sudah diverifikasi aktif.
- Facebook bisa meminta login, persetujuan bergabung, atau menolak akses.
- APK yang dibangun workflow ini adalah **debug APK** untuk pengujian/instalasi manual, bukan rilis Play Store.
